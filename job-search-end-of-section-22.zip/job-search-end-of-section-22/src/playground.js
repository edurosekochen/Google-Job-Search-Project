const sushi = [
  "Tuna",
  "Salmon",
  "Yellowtail",
  "Eel",
  "Shrimp",
  "Octopus",
  "Uni",
];

console.log(sushi.slice(2, 5));
