<template>
  <hero />
</template>

<script>
import Hero from "@/components/JobSearch/Hero.vue";

export default {
  name: "HomeView",
  components: {
    Hero,
  },
};
</script>
