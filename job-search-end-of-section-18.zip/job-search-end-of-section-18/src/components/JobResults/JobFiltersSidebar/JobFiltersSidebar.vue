<template>
  <div
    class="
      flex flex-col
      p-4
      bg-white
      border-r border-solid border-brand-gray-1
      w-96
    "
  >
    Job Filters Sidebar
  </div>
</template>

<script>
export default {
  name: "JobFiltersSidebar",
};
</script>
