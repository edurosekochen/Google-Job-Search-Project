const favoriteFood = "sushi";

const goodFoods = {
  [favoriteFood]: true,
};

console.log(goodFoods);
